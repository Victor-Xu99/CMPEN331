`timescale 1ns / 1ps

module testbench;

    reg clock;

    // IF/ID
    wire [31:0] pc, dinstOut;

    // ID/EXE
    wire ewreg, em2reg, ewmem;
    wire [3:0] ealuc;
    wire ealuimm;
    wire [4:0] edestReg;
    wire [31:0] eqa, eqb, eimm32;

    // EXE/MEM
    wire mwreg, mm2reg, mwmem;
    wire [4:0] mdestReg;
    wire [31:0] mr, mqb;

    // MEM/WB
    wire wwreg, wm2reg;
    wire [4:0] wdestReg;
    wire [31:0] wr, wdo;
    
    wire [31:0] wbData;

    // DUT
    TopModule dut(
        .clock(clock),
        .pc(pc),
        .dinstOut(dinstOut),

        .ewreg(ewreg), .em2reg(em2reg), .ewmem(ewmem),
        .ealuc(ealuc), .ealuimm(ealuimm),
        .edestReg(edestReg), .eqa(eqa), .eqb(eqb), .eimm32(eimm32),

        .mwreg(mwreg), .mm2reg(mm2reg), .mwmem(mwmem),
        .mdestReg(mdestReg), .mr(mr), .mqb(mqb),

        .wwreg(wwreg), .wm2reg(wm2reg),
        .wdestReg(wdestReg), .wr(wr), .wdo(wdo),
        
        .wbData(wbData)
    );

    initial begin
        clock = 0;
        forever #1 clock = ~clock;
    end

    initial begin
        $monitor("%t | PC=%h | EX/MEM: mr=%h mqb=%h mdest=%d | MEM/WB: wr=%h wdo=%h wdest=%d",
            $time, pc, mr, mqb, mdestReg, wr, wdo, wdestReg);
    end

    initial begin
        #200 $finish;
    end

endmodule
