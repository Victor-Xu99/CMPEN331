`timescale 1ns / 1ps
module RegisterFile(
    input [31:0] wbData,
    input [4:0] rs,rt,wdestReg,
    input wwreg, clk, 
    output reg [31:0] qa, qb
    );
    reg [31:0] regs [0:31];
    
    initial begin: init_regs
        integer i;
        for (i=0; i < 32; i = i + 1)
            regs[i] = 0;
        end
    
    always @(*) begin
        if (rs == 5'd0)
            qa = 32'b0;
        else
            qa = regs[rs];
        if (rt == 5'd0)
            qb = 32'b0;
        else
            qb = regs[rt];
    end
    always @(negedge clk) begin
        if (wwreg)
            regs[wdestReg] = wbData;
    end
endmodule
