`timescale 1ns / 1ps
module ControlUnit(
    input [5:0] op,
    input [5:0] func,
    output reg wreg,
    output reg m2reg,
    output reg wmem,
    output reg [3:0] aluc,
    output reg aluimm,
    output reg regrt 
    );
    always @(*) begin 
        //defaults
        wreg  = 1'b0;
        m2reg = 1'b0;
        wmem  = 1'b0;
        aluc  = 4'b0010; // default to ADD
        aluimm= 1'b0;
        regrt = 1'b0;
        case(op)
            6'b000000: //R-Format
            begin
                wreg = 1'b1;
                m2reg = 1'b0;
                wmem = 1'b0;
                aluimm = 1'b0;
                regrt = 1'b0; //rd
                case (func) 
                    6'b100000: //ADD Instruction
                        aluc <= 4'b0010;
                    6'b100010:
                        aluc <= 4'b0110;
                endcase
            end
            6'b100011: //lw
            begin
                wreg <= 1'b1;
                m2reg <= 1'b1;
                wmem <= 1'b0;
                aluimm <= 1'b1;
                regrt <= 1'b1; //rt
                aluc <= 4'b0010;
            end
        endcase
    end
endmodule
