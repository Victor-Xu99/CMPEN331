`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/03/2025 04:21:07 PM
// Design Name: 
// Module Name: SExtend
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module SExtend(
        input [15:0] imm,
        output reg [31:0] imm32
    );
    always @(*) begin
        imm32 = {{16{imm[15]}}, imm};
    end
endmodule
