`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/03/2025 10:27:38 AM
// Design Name: 
// Module Name: TopModule
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module TopModule(
        input clock,
        output [31:0] pc,
        output [31:0] dinstOut,
        output ewreg,
        output em2reg,
        output ewmem,
        output [3:0] ealuc,
        output ealuimm,
        output [4:0] edestReg,
        output [31:0] eqa,
        output [31:0] eqb,
        output [31:0] eimm32
    );
    wire [31:0] pc_next;
    wire [31:0] pc_current;
    wire [31:0] out_inst;
    wire [31:0] out_dinst;
    ProgramCounter PC_inst (
        .clock(clock),
        .nextPc(pc_next),
        .pc(pc_current)
    );
    Adder Add_inst (
        .pc(pc_current),
        .nextPc(pc_next)
    );
    InstructionMemory InstructionMem_inst (
        .pc(pc_current),
        .instOut(out_inst)
    );
    IF_ID_Register IFID_inst (
        .clock(clock),
        .instOut(out_inst),
        .dinstOut(out_dinst)
    );
    wire [5:0] inst_op;
    wire [5:0] inst_func;
    wire [4:0] inst_rd;
    wire [4:0] inst_rt;
    wire [4:0] inst_rs;
    wire [15:0] inst_imm;
    assign inst_op = out_dinst[31:26];
    assign inst_func = out_dinst[5:0];
    assign inst_rs = out_dinst[25:21];
    assign inst_rt = out_dinst[20:16];
    assign inst_rd = out_dinst[15:11];
    assign inst_imm = out_dinst[15:0];
    
    wire out_wreg;
    wire out_m2reg;
    wire out_wmem;
    wire [3:0] out_aluc;
    wire out_aluimm;
    wire out_regrt;
    
    ControlUnit Control_inst (
        .op(inst_op),
        .func(inst_func),
        .wreg(out_wreg),
        .m2reg(out_m2reg),
        .wmem(out_wmem),
        .aluc(out_aluc), //4bits
        .aluimm(out_aluimm),
        .regrt(out_regrt)
    );
    wire [4:0] out_destReg;
    Mux_RegDst MuxRegDst_inst (
        .rt(inst_rt),
        .rd(inst_rd),
        .regrt(out_regrt),
        .destReg(out_destReg)
    );
    wire [31:0] out_qa;
    wire [31:0] out_qb;
    RegisterFile Register_inst (
        .rs(inst_rs),
        .rt(inst_rt),
        .qa(out_qa),
        .qb(out_qb)
    );
    
    wire [31:0] out_imm32;
    SExtend Extend_inst (
        .imm(inst_imm),
        .imm32(out_imm32)
    );
    
    ID_EXE_Register IDEXE_inst (
        .wreg(out_wreg),
        .m2reg(out_m2reg),
        .wmem(out_wmem),
        .aluc(out_aluc),
        .aluimm(out_aluimm),
        .destReg(out_destReg),
        .qa(out_qa),
        .qb(out_qb),
        .imm32(out_imm32),
        .clock(clock),
        .ewreg(ewreg),
        .em2reg(em2reg),
        .ewmem(ewmem),
        .ealuc(ealuc),
        .ealuimm(ealuimm),
        .edestReg(edestReg),
        .eqa(eqa),
        .eqb(eqb),
        .eimm32(eimm32)
    );
    assign dinstOut = out_dinst;
    assign pc = pc_current;
endmodule

