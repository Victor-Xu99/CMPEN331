`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/03/2025 12:00:17 PM
// Design Name: 
// Module Name: Mux_RegDst
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Mux_RegDst(
    input [4:0] rt,
    input [4:0] rd,
    input regrt,
    output [4:0] destReg
    );
    assign destReg = (regrt) ? rt : rd;
endmodule
