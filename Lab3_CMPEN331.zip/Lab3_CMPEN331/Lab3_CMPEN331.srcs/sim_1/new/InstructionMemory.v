`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/03/2025 10:27:38 AM
// Design Name: 
// Module Name: InstructionMemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module InstructionMemory(
        input [31:0] pc,
        output reg [31:0] instOut
    );
        reg [31:0] memory [0:63];
        initial begin
            memory[25] = 32'h8C220000; //lw $v0, 0($at)
            memory[26] = 32'h8C230004; //lw $v1, 4($at) 
        end
            always @(*) begin
                instOut <= memory[pc[7:2]]; //Only need 6 bits since we only have 64 wods in memory
        end
endmodule
