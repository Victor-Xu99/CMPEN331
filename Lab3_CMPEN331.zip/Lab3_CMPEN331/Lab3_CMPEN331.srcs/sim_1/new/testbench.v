`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/03/2025 10:01:34 PM
// Design Name: 
// Module Name: testbench
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module testbench;  // no inputs/outputs

    // --- Clock ---
    reg clock;
    localparam CLK_PERIOD = 10; 

    // --- Probes (wires) from the datapath ---
    wire [31:0] pc;
    wire [31:0] dinstOut;

    // ID -> EXE latched signals
    wire        ewreg;
    wire        em2reg;
    wire        ewmem;
    wire [3:0]  ealuc;
    wire        ealuimm;
    wire [4:0]  edestReg;
    wire [31:0] eqa;
    wire [31:0] eqb;
    wire [31:0] eimm32;

    // --- DUT instantiation (keep datapath separate) ---
    TopModule dut (
        .clock   (clock),
        .pc      (pc),
        .dinstOut(dinstOut),
        .ewreg   (ewreg),
        .em2reg  (em2reg),
        .ewmem   (ewmem),
        .ealuc   (ealuc),
        .ealuimm (ealuimm),
        .edestReg(edestReg),
        .eqa     (eqa),
        .eqb     (eqb),
        .eimm32  (eimm32)
    );

    // --- Clock generation ---
    initial begin
        clock = 1'b0;          // MUST start at 0
        forever #1 clock = ~clock;
    end

    // --- Text log (optional but handy) ---
    initial begin
        $timeformat(-9, 1, " ns", 6); // show time in ns
        $display("time       pc        dinstOut      | ewreg em2reg ewmem  ealuc  ealuimm edestReg   eqa        eqb        eimm32");
        $monitor("%t  %h  %h  |   %b      %b      %b     %b     %b     %2d    %h  %h  %h",
                 $realtime, pc, dinstOut,
                 ewreg, em2reg, ewmem, ealuc, ealuimm, edestReg, eqa, eqb, eimm32);
    end

    // --- Run length & finish ---
    initial begin
        // let run for a few cycles to fetch at 100 and 104
        #(20*CLK_PERIOD);
        $finish;
    end
endmodule
