module InstructionMemory(
        input [31:0] pc,
        output reg [31:0] instOut
    );
        reg [31:0] memory [0:63];
        initial begin
            memory[25] = 32'h00221820; //add $3, $1, $2
            memory[26] = 32'h01232022; //sub $4, $9, $3 
            memory[27] = 32'h00692825; //or $5, $3, $9
            memory[28] = 32'h00693026; //xor $6, $3, $9
            memory[29] = 32'h00693824; //and $7, $3, $9
        end
            always @(*) begin
                instOut <= memory[pc[7:2]]; //Only need 6 bits since we only have 64 wods in memory
        end
endmodule
