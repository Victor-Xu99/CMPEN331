`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/05/2025 11:01:14 AM
// Design Name: 
// Module Name: WbMux
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module WbMux(
    input [31:0] wr, wdo,
    input wm2reg,
    output reg [31:0] wbData
    );
    always @(*) begin
        wbData = wm2reg ? wdo:wr;
    end
endmodule
