`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/03/2025 10:27:38 AM
// Design Name: 
// Module Name: TopModule
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: CMPEN 331 Lab 3 - IF and ID Pipeline Implementation
// 
//////////////////////////////////////////////////////////////////////////////////

module TopModule(
    input wire clock,
    output wire [31:0] wbData
    );

    // IF/ID outputs
    wire[31:0] pc;
    wire [31:0] dinstOut;

    // ID/EXE outputs
    wire ewreg, em2reg, ewmem; 
    wire [3:0] ealuc; 
    wire ealuimm;
    wire [4:0] edestReg;  
    wire [31:0] eqa, eqb, eimm32;

    // EXE/MEM outputs
    wire mwreg, mm2reg, mwmem;
    wire [4:0] mdestReg;
    wire [31:0] mr, mqb;

    // MEM/WB outputs
    wire wwreg, wm2reg;
    wire [4:0] wdestReg;
    wire [31:0] wr, wdo;
    
    wire [31:0] wbData;

    wire [31:0] pc_next;
    wire [31:0] pc_current;
    wire [31:0] out_inst;
    wire [31:0] out_dinst;

    ProgramCounter PC_inst (
        .clock  (clock),
        .nextPc (pc_next),
        .pc     (pc_current)
    );

    Adder Add_inst (
        .pc     (pc_current),
        .nextPc (pc_next)
    );

    InstructionMemory InstructionMem_inst (
        .pc      (pc_current),
        .instOut (out_inst)
    );

    IF_ID_Register IFID_inst (
        .clock    (clock),
        .instOut  (out_inst),
        .dinstOut (out_dinst)
    );

    // Field extraction
    wire [5:0]  inst_op   = out_dinst[31:26];
    wire [5:0]  inst_func = out_dinst[5:0];
    wire [4:0]  inst_rs   = out_dinst[25:21];
    wire [4:0]  inst_rt   = out_dinst[20:16];
    wire [4:0]  inst_rd   = out_dinst[15:11];
    wire [15:0] inst_imm  = out_dinst[15:0];

    // Control signals
    wire out_wreg;
    wire out_m2reg;
    wire out_wmem;
    wire [3:0] out_aluc;
    wire out_aluimm;
    wire out_regrt;
    
    wire [1:0] fwdaw;
    wire [1:0] fwdbw;
    ControlUnit Control_inst (
        .op     (inst_op),
        .func   (inst_func),
        .rs(inst_rs),
        .rt(inst_rt),
        .ern(edestRegw),
        .mrn(mdestRegw),
        .mm2reg(mm2regw),
        .mwreg(mwregw),
        .em2reg(out_m2reg),
        .ewreg(out_wreg),
        .wreg   (out_wreg),
        .m2reg  (out_m2reg),
        .wmem   (out_wmem),
        .aluc   (out_aluc),
        .aluimm (out_aluimm),
        .regrt  (out_regrt),
        .fwda(fwdaw),
        .fwdb(fwdbw)
    );
    
    wire [31:0] MUXaw;
    wire [31:0] MUXbw;
    fwdMux fwdMuxA (
        .q(out_qa),
        .r(ALU_r),
        .mr(mrw),
        .do(mdow),
        .select(fwdaw),
        .fwd(MUXaw)
    );
    
    fwdMux fwdMuxB (
        .q(out_qb),
        .r(ALU_r),
        .mr(mrw),
        .do(mdow),
        .select(fwdbw),
        .fwd(MUXbw)
    );

    // regrt mux (RegDst)
    wire [4:0] out_destReg;
    Mux_RegDst MuxRegDst_inst (
        .rt      (inst_rt),
        .rd      (inst_rd),
        .regrt   (out_regrt),
        .destReg (out_destReg)
    );

    // Register File
    wire [31:0] out_qa, out_qb;
    RegisterFile Register_inst (
        .rs (inst_rs),
        .rt (inst_rt),
        .wdestReg(wdestRegw),
        .wbData(wbDataw),
        .wwreg(wwregw),
        .clk(clock), //clock signal is inverted within register
        .qa (out_qa),
        .qb (out_qb)
    );

    // Sign Extension
    wire [31:0] out_imm32;
    SExtend Extend_inst (
        .imm   (inst_imm),
        .imm32 (out_imm32)
    );
    
    wire ealuimmw; 
    wire [31:0] eqaw;
    wire [31:0] eqbw;
    wire [31:0] eimm32w; 
    wire [3:0] ealucw; 
    wire ewregw;
    wire em2regw;
    wire ewmemw;
    wire [4:0] edestRegw;
    
    ID_EXE_Register IDEXE_inst (
        .wreg     (out_wreg),
        .m2reg    (out_m2reg),
        .wmem     (out_wmem),
        .aluc     (out_aluc),
        .aluimm   (out_aluimm),
        .destReg  (out_destReg),
        .qa       (MUXaw),
        .qb       (MUXbw),
        .imm32    (out_imm32),
        .clock    (clock),
        .ewreg    (ewregw),
        .em2reg   (em2regw),
        .ewmem    (ewmemw),
        .ealuc    (ealucw),
        .ealuimm  (ealuimmw),
        .edestReg (edestRegw),
        .eqa      (eqaw),
        .eqb      (eqbw),
        .eimm32   (eimm32w)
    );
    assign ealuimm = ealuimmw;
    assign eqa = eqaw;
    assign eqb = eqbw;
    assign eimm32 = eimm32w; 
    assign ealuc = ealucw;
    assign ewreg = ewregw;
    assign em2reg = em2regw;
    assign ewmem = ewmemw;
    assign edestReg = edestRegw;

    wire [31:0] mux_alu_b;
    Mux_ALU Mux_ALU_inst (
        .eqb (eqbw),
        .eimm32 (eimm32w),
        .ealuimm (ealuimmw),
        .b (mux_alu_b)
    );
    
    wire [31:0] ALU_r;
    ALU ALU_inst (
        .eqa (eqaw), 
        .b (mux_alu_b),
        .ealuc (ealucw),
        .r (ALU_r)
    ); 
    
    wire [4:0] mdestRegw;
    wire [31:0] mrw;
    wire [31:0] mqbw;
    wire mwregw;
    wire mm2regw;
    wire mwmemw;
    
    EXE_MEM_Register EXEMEM_inst (
        .ewreg (ewregw),
        .em2reg (em2regw),
        .ewmem (ewmemw),
        .clk (clock),
        .edestReg (edestRegw),
        .r (ALU_r),
        .eqb (eqbw),
        .mwreg (mwregw),
        .mm2reg (mm2regw),
        .mwmem  (mwmemw),
        .mdestReg (mdestRegw),
        .mr (mrw),
        .mqb (mqbw)
    );
    assign mwreg = mwregw;
    assign mm2reg = mm2regw;
    assign mwmem = mwmemw;
    assign mdestReg = mdestRegw;
    assign mr = mrw;
    assign mqb = mqbw;
    
    wire [31:0] mdow;
    DataMemory DataMemory_inst(
        .mr (mrw),
        .mqb (mqbw),
        .mwmem (mwmemw),
        .clk (clock),
        .mdo (mdow)
    );
    
    wire [31:0] wrw;
    wire [31:0] wdow;
    wire [4:0] wdestRegw;
    wire wwregw;
    wire wm2regw;
    MEM_WB_Register MEMWB_inst (
        .mwreg (mwregw),
        .mm2reg (mm2regw),
        .clk (clock),
        .mr (mrw),
        .mdo (mdow),
        .mdestReg (mdestRegw),
        .wwreg (wwregw),
        .wm2reg (wm2regw),
        .wdestReg (wdestRegw),
        .wr (wrw),
        .wdo (wdow)
    );
    assign dinstOut = out_dinst;
    assign pc       = pc_current;
    assign wr = wrw;
    assign wdo = wdow;
    assign wm2reg = wm2regw;
    assign wwreg = wwregw;
    assign wdestReg = wdestRegw;
    
    wire [31:0] wbDataw;
    WbMux WbMuxInst (
        .wr(wrw),
        .wdo(wdow),
        .wm2reg(wm2regw),
        .wbData(wbDataw)
    );
    assign wbData = wbDataw;
    
endmodule
