`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/23/2025 01:32:36 PM
// Design Name: 
// Module Name: Mux_ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Mux_ALU(
    input [31:0] eqb, eimm32,
    input ealuimm,
    output reg [31:0] b
    );
    always @(*) begin
        case (ealuimm)
            1'b0: b = eqb;
            1'b1: b = eimm32;
        endcase
    end
endmodule
