`timescale 1ns / 1ps
module RegisterFile(
    input [31:0] wbData,
    input [4:0] rs,rt,wdestReg,
    input wwreg, clk, 
    output reg [31:0] qa, qb
    );
    reg [31:0] regs [0:31];
    
    initial begin: init_regs
        integer i;
        regs[0] = 32'h00000000;
        regs[1] = 32'hA00000AA;
        regs[2] = 32'h10000011;
        regs[3] = 32'h20000022;
        regs[4] = 32'h30000033;
        regs[5] = 32'h40000044;
        regs[6] = 32'h50000055;
        regs[7] = 32'h60000066;
        regs[8] = 32'h70000077;
        regs[9] = 32'h80000088;
        regs[10] = 32'h90000099;
        for (i=11; i < 32; i = i + 1)
            regs[i] = 0;
        end
    
    always @(*) begin
        if (rs == 5'd0)
            qa = 32'b0;
        else
            qa = regs[rs];
        if (rt == 5'd0)
            qb = 32'b0;
        else
            qb = regs[rt];
    end
    always @(negedge clk) begin
        if (wwreg)
            regs[wdestReg] = wbData;
    end
endmodule
