`timescale 1ns / 1ps
module Adder(
    input [31:0] pc,
    output [31:0] nextPc
    );
    assign nextPc = pc + 4;
endmodule
