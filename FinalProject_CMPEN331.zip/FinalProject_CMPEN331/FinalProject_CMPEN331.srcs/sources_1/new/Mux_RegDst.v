`timescale 1ns / 1ps
module Mux_RegDst(
    input [4:0] rt,
    input [4:0] rd,
    input regrt,
    output [4:0] destReg
    );
    assign destReg = (regrt) ? rt : rd;
endmodule
