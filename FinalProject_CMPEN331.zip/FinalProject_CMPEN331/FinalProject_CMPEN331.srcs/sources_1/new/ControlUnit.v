`timescale 1ns / 1ps
module ControlUnit(
    input [5:0] op, func, 
    
    //new inputs for hazard detection and forwarding
    input [4:0] rs, rt,
    input [4:0] ern, mrn,
    input mm2reg, mwreg, em2reg, ewreg,
    
    output reg wreg,
    output reg m2reg,
    output reg wmem,
    output reg [3:0] aluc,
    output reg aluimm,
    output reg regrt,
    
    //new outputs for hazard detections and worwarding
    output reg [1:0] fwda, fwdb
    );
    
    always @(*) begin 
        //defaults
        wreg  = 1'b0;
        m2reg = 1'b0;
        wmem  = 1'b0;
        aluc  = 4'b0010; // default to ADD
        aluimm= 1'b0;
        regrt = 1'b0;
        fwda = 2'b00;
        fwdb = 2'b00;
        
        case(op)
            6'b000000: //R-Format
            begin
                wreg = 1'b1;
                m2reg = 1'b0;
                wmem = 1'b0;
                aluimm = 1'b0;
                regrt = 1'b0; //rd
                case (func) 
                    6'b100000: //ADD Instruction
                        aluc = 4'b0010;
                    6'b100010: //SUB instruction
                        aluc = 4'b0110;
                    6'b100100: //AND instruction
                        aluc = 4'b0000;
                    6'b100101: //OR instruction
                        aluc = 4'b0001;
                    6'b100110: //XOR instruction
                        aluc = 4'b0011;
                        
                endcase
            end
            
            6'b100011: //lw
            begin
                wreg = 1'b1;
                m2reg = 1'b1;
                wmem = 1'b0;
                aluimm = 1'b1;
                regrt = 1'b1; //rt
                aluc = 4'b0010;
            end
        endcase
        
            //00 -> no hazards, forward qa or qb depending on multiplexer
            //01 -> forward r 
            //10 -> forward mr 
            //11 -> forward do
            //fwrda
            if (mwreg && (mrn != 5'b00000) && (mrn == rs)) begin 
                fwda = (mm2reg) ? 2'b11 : 2'b10;
            end 
            else if (ewreg && (ern != 5'b00000) && (ern == rs)) begin
                fwda = 2'b01;
            end
        
            //fwrdb 
            if (mwreg && (mrn != 5'b00000) && (mrn == rt)) begin 
                fwdb = (mm2reg) ? 2'b11 : 2'b10;
            end   
            else if (ewreg && (ern != 5'b00000) && (ern == rt)) begin
                fwdb = 2'b01;
            end
    end
endmodule
