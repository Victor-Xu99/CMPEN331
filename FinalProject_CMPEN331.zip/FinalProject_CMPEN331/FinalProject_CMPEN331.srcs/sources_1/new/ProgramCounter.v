`timescale 1ns / 1ps
module ProgramCounter(
        input clock,
        input [31:0] nextPc,
        output reg [31:0] pc
);
        initial begin
            pc = 32'd100;
    end
        always @(posedge clock) begin
            pc <= nextPc;
        end
endmodule
