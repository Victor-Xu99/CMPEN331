`timescale 1ns / 1ps

module testbench;

    reg clock;

    // IF/ID
    wire [31:0] pc, dinstOut;

    
    // ID/EXE
    wire ewreg, em2reg, ewmem;
    wire [3:0] ealuc;
    wire ealuimm;
    wire [4:0] edestReg;
    wire [31:0] eqa, eqb, eimm32;
    

    // EXE/MEM
    wire mwreg, mm2reg, mwmem;
    wire [4:0] mdestReg;
    wire [31:0] mr, mqb;

    // MEM/WB
    wire wwreg, wm2reg;
    wire [4:0] wdestReg;
    wire [31:0] wr, wdo;
    
    //FWD
    wire [1:0] fwda;
    wire [1:0] fwdb;
    wire [31:0] qa;
    wire [31:0] qb;
    wire [31:0] MUXaw;
    wire [31:0] MUXbw;
    
    wire [31:0] wbData;
    // DUT
    TopModule dut(
        .clock(clock),
        .wbData(wbData)
    );
    
    assign pc = dut.pc;
    assign dinstOut = dut.dinstOut;
    assign ewreg = dut.ewreg;
    assign em2reg = dut.em2reg;
    assign ewmem = dut.ewmem;
    assign ealuc = dut.ealuc;
    assign ealuimm = dut.ealuimm;
    assign edestReg = dut.edestReg;
    assign eqa = dut.eqa;
    assign eqb = dut.eqb;
    assign eimm32 = dut.eimm32;
    assign mwreg = dut.mwreg;
    assign mm2reg = dut.mm2reg;
    assign mwmem = dut.mwmem;
    assign mdestReg = dut.mdestReg;
    assign mr = dut.mr;
    assign mqb = dut.mqb;
    assign wwreg = dut.wwreg;
    assign wm2reg = dut.wm2reg;
    assign wdestReg = dut.wdestReg;
    assign wr = dut.wr;
    assign wdo = dut.wdo;
    assign qa = dut.out_qa;
    assign qb = dut.out_qb;
    assign fwda = dut.fwdaw;
    assign fwdb = dut.fwdbw;
    assign MUXaw = dut.MUXaw; 
    assign MUXbw = dut.MUXbw;
    assign qa = dut.out_qa;
    assign qb = dut.out_qb;
    
    initial begin
        clock = 0;
        forever #1 clock = ~clock;
    end

    initial begin
        $monitor("%t | PC=%h | EX/MEM: mr=%h mqb=%h mdest=%d | MEM/WB: wr=%h wdo=%h wdest=%d",
            $time, pc, mr, mqb, mdestReg, wr, wdo, wdestReg, MUXaw, MUXbw);
    end

    initial begin
        #200 $finish;
    end

endmodule
