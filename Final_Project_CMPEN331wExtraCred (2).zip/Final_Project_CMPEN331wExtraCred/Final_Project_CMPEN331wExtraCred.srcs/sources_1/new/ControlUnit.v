`timescale 1ns / 1ps
module ControlUnit(
    input [5:0] op, func, 
    
    //new inputs for hazard detection and forwarding
    input [4:0] rs, rt,
    input [4:0] ern, mrn,
    input mm2reg, mwreg, em2reg, ewreg,
    
    //new input for stall, branching, and jumping
    input rsrtequ,
    
    output reg wreg,
    output reg m2reg,
    output reg wmem,
    output reg [3:0] aluc,
    output reg aluimm,
    output reg regrt,
    
    //new outputs for hazard detections and worwarding
    output reg [1:0] fwda, fwdb,
    
    //new outputs for stall, branching, jumping
    output reg [1:0] pcsrc,
    output reg wpcir,
    output reg jal,
    output reg sext,
    output reg shift
    );
    
    always @(*) begin 
        //defaults
        wreg  = 1'b0;
        m2reg = 1'b0;
        wmem  = 1'b0;
        aluc  = 4'b0010; // default to ADD
        aluimm= 1'b0;
        regrt = 1'b0;
        fwda = 2'b00;
        fwdb = 2'b00;
        wpcir = 1'b1;
        pcsrc = 2'b00;
        jal = 1'b0;
        sext = 1'b1;
        shift = 1'b0;
        
        case(op)
            6'b000000: //R-Format
            begin
                case (func) 
                    6'b000000: begin //sll 
                        wreg = 1'b1;
                        aluc = 4'b1000;
                        shift = 1'b1;
                    end
                    6'b000011: begin //sra 
                        wreg = 1'b1;
                        aluc = 4'b1011;
                        shift = 1'b1;
                    end
                    6'b000010: begin // srl 
                        wreg = 1'b1; 
                        aluc = 4'b1010; 
                        shift = 1'b1;
                    end
                    6'b001000: begin // jr
                        pcsrc = 2'b11; //jpc
                    end 
                    6'b100000: begin // ADD instruction
                        wreg = 1'b1; 
                        aluc = 4'b0010; 
                    end
                    6'b100010: begin // SUB instruction
                        wreg = 1'b1; 
                        aluc = 4'b0110; 
                    end
                    6'b100100: begin // AND instruction
                        wreg = 1'b1; 
                        aluc = 4'b0000; 
                    end
                    6'b100101: begin // OR instruction
                        wreg = 1'b1; 
                        aluc = 4'b0001; 
                    end
                    6'b100110: begin // XOR instruction
                        wreg = 1'b1; 
                        aluc = 4'b0011; 
                    end 
                    default: ; //nop
                endcase
            end
            
           // I-Format
            6'b001000: // addi
            begin
                wreg = 1'b1; 
                aluimm = 1'b1; 
                regrt = 1'b1; 
                aluc = 4'b0010; 
                sext = 1'b1;
            end
            6'b001100: // andi
            begin
                wreg = 1'b1; 
                aluimm = 1'b1; 
                regrt = 1'b1; 
                aluc = 4'b0000; 
                sext = 1'b0;
            end
            6'b001101: // ori
            begin
                wreg = 1'b1; 
                aluimm = 1'b1; 
                regrt = 1'b1; 
                aluc = 4'b0001; 
                sext = 1'b0;
            end
            6'b001110: // xori
            begin
                wreg = 1'b1; 
                aluimm = 1'b1; 
                regrt = 1'b1; 
                aluc = 4'b0011; 
                sext = 1'b0; 
            end
            6'b001111: // lui
            begin
                wreg = 1'b1; 
                aluimm = 1'b1; 
                regrt = 1'b1; 
                aluc = 4'b1111;
            end
            6'b100011: // lw
            begin
                wreg = 1'b1; 
                m2reg = 1'b1;
                aluimm = 1'b1; 
                regrt = 1'b1; 
                aluc = 4'b0010;
            end
            6'b101011: // sw
            begin
                wmem = 1'b1; 
                aluimm = 1'b1; 
                aluc = 4'b0010;
            end
            6'b000100: // beq
            begin
                pcsrc = (rsrtequ) ? 2'b01 : 2'b00; // Branch if equal
            end

            // J-Format
            6'b000010: // j
            begin
                pcsrc = 2'b10;
            end
            6'b000011: // jal
            begin
                wreg = 1'b1; 
                jal = 1'b1; 
                pcsrc = 2'b10;
            end
            
            default: ; 
        endcase
        
            //00 -> no hazards, forward qa or qb depending on multiplexer
            //01 -> forward r 
            //10 -> forward mr 
            //11 -> forward do
            //fwrda
            if (mwreg && (mrn != 5'b00000) && (mrn == rs)) begin 
                fwda = (mm2reg) ? 2'b11 : 2'b10;
            end 
            else if (ewreg && (ern != 5'b00000) && (ern == rs)) begin
                fwda = 2'b01;
            end
        
            //fwrdb 
            if (mwreg && (mrn != 5'b00000) && (mrn == rt)) begin 
                fwdb = (mm2reg) ? 2'b11 : 2'b10;
            end   
            else if (ewreg && (ern != 5'b00000) && (ern == rt)) begin
                fwdb = 2'b01;
            end
            
            //stall logic
            if (ewreg && em2reg && ((ern == rs) || (ern == rt))) begin
                wpcir = 1'b0;
                wreg = 1'b0;
                wmem = 1'b0;
            end
        end
endmodule
