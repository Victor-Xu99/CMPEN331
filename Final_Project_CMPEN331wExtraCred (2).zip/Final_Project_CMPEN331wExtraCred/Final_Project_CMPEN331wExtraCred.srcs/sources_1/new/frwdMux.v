`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/17/2025 11:57:35 PM
// Design Name: 
// Module Name: frwdMux
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fwdMux(
        input [31:0] q, //can be qa or qb
        input [31:0] r, mr, do,
        input [1:0] select,
        output reg [31:0] fwd
    );
        always @(*) begin
            case(select) 
                2'b00: fwd = q;
                2'b01: fwd = r;
                2'b10: fwd = mr;
                2'b11: fwd = do;
            endcase
        end  
endmodule
