`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/23/2025 01:32:36 PM
// Design Name: 
// Module Name: ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ALU(
    input [31:0] eqa, b,
    input [3:0] ealuc,
    output reg [31:0] r
    );
    always @(*) begin
        case (ealuc)
            4'b0010: r = eqa + b; //ADD
            4'b0110: r = eqa - b; //SUB
            4'b0000: r = eqa & b; //AND
            4'b0001: r = eqa | b; //OR
            4'b0011: r = eqa ^ b; //XOR
            4'b0111: r = (eqa < b) ? 32'd1 : 32'd0; //SLT
            4'b1000: r = b << eqa; //SLL
            4'b1010: r = b >> eqa; //SRL
            4'b1011: r = $signed(b) >>> eqa; //SRA
            4'b1111: r = {b[15:0], 16'b0}; //LUI
            default: r = 32'b0; //safety
        endcase
    end
endmodule
