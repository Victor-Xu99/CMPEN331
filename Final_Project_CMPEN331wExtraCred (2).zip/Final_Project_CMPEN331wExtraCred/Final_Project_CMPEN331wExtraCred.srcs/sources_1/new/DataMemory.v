`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/23/2025 01:32:36 PM
// Design Name: 
// Module Name: DataMemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module DataMemory(
    input [31:0] mr, mqb,
    input mwmem, clk,
    output reg [31:0] mdo
    );
    reg [31:0] memory [0:63];
    initial begin : init_data
        integer i;
        for (i = 0; i < 32; i = i + 1) begin
            memory[i] = 32'b0;
        end
        memory[5'h14] = 32'h000000a3; // (Byte addr 0x50)
        memory[5'h15] = 32'h00000027; // (Byte addr 0x54)
        memory[5'h16] = 32'h00000079; // (Byte addr 0x58)
        memory[5'h17] = 32'h00000115; // (Byte addr 0x5c)
    end
    always @(*) begin
        mdo = memory[mr[7:2]];
    end
    
    always @(negedge clk) begin
        if (mwmem) 
            memory[mr[7:2]] <= mqb;
    end
endmodule
