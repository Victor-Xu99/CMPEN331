`timescale 1ns / 1ps

module TopModule(
    input wire clock,
    output wire [31:0] pc,
    output wire [31:0] dinstOut,
    output wire ewreg, em2reg, ewmem, ealuimm,
    output wire [3:0] ealuc,
    output wire [4:0] edestReg,
    output wire [31:0] eqa, eqb, eimm32,
    output wire mwreg, mm2reg, mwmem,
    output wire [4:0] mdestReg,
    output wire [31:0] mr, mqb,
    output wire wwreg, wm2reg,
    output wire [4:0] wdestReg,
    output wire [31:0] wr, wdo,
    output wire [31:0] wbData
    );

    wire [31:0] pc_next;
    wire [31:0] pc_current;
    wire [31:0] out_inst;
    wire [31:0] out_dinst;
    wire [31:0] npc;
    wire [31:0] bpc;
    wire [31:0] jpc;
    wire [31:0] dpc4;
    wire [31:0] MUXaw;
    wire [31:0] MUXbw;
    wire [31:0] out_qa;
    wire [31:0] out_qb;
    wire [31:0] out_imm32;
    wire [31:0] ealu;
    wire [31:0] ALU_r;
    wire [31:0] epc4;
    wire [31:0] epc8;
    wire [31:0] eqaw;
    wire [31:0] eqbw;
    wire [31:0] eimm32w;
    wire [31:0] mux_alu_a;
    wire [31:0] mux_alu_b;
    wire [31:0] mrw;
    wire [31:0] mqbw;
    wire [31:0] mdow;
    wire [31:0] wrw;
    wire [31:0] wdow;
    
    wire [5:0] inst_op = out_dinst[31:26];
    wire [5:0] inst_func = out_dinst[5:0];
    wire [4:0] inst_rs = out_dinst[25:21];
    wire [4:0] inst_rt = out_dinst[20:16];
    wire [4:0] inst_rd = out_dinst[15:11];
    wire [4:0] inst_sa = out_dinst[10:6];
    wire [31:0] sa_ext = {27'b0, inst_sa};
    wire [15:0] inst_imm = out_dinst[15:0];
    wire [25:0] inst_target = out_dinst[25:0];
    
    wire [4:0] out_destReg;
    wire [4:0] edestRegw;
    wire [4:0] mdestRegw;
    wire [4:0] wdestRegw;
    wire [4:0] ern0;
    wire [4:0] ern;
    wire [4:0] drn = out_regrt ? inst_rt : inst_rd;

    wire [3:0] out_aluc;
    wire [3:0] ealucw;
    wire [1:0] fwdaw;
    wire [1:0] fwdbw;
    wire [1:0] pcsrc;

    wire out_wreg, out_m2reg, out_wmem, out_aluimm, out_regrt;
    wire ewregw, em2regw, ewmemw, ealuimmw, ejal, eshift;
    wire mwregw, mm2regw, mwmemw;
    wire wwregw, wm2regw;
    wire jal, shift, sext, wpcir, rsrtequ;

    assign bpc = ({{14{inst_imm[15]}}, inst_imm, 2'b00}) + dpc4;
    assign jpc = {dpc4[31:28], inst_target, 2'b00};
    assign rsrtequ = (MUXbw == MUXaw);
    assign epc8 = epc4 + 4;
    assign mux_alu_a = eshift ? sa_ext : eqaw;
    assign ealu = ejal ? epc8 : ALU_r;

    ProgramCounter PC_inst (
        .clock  (clock),
        .nextPc (npc),
        .wpcir  (wpcir),
        .pc     (pc_current)
    );

    Adder Add_inst (
        .pc     (pc_current),
        .nextPc (pc_next)
    );
    
    pcMUX PC_MUX (
        .pc4    (pc_next),
        .bpc    (bpc),
        .da     (MUXaw),
        .jpc    (jpc),
        .pcsrc  (pcsrc),
        .npc    (npc)
    );

    InstructionMemory InstructionMem_inst (
        .pc      (pc_current),
        .instOut (out_inst)
    );

    IF_ID_Register IFID_inst (
        .clock    (clock),
        .pc4      (pc_next),
        .wpcir    (wpcir),
        .instOut  (out_inst),
        .dinstOut (out_dinst),
        .dpc4     (dpc4)
    );

    ControlUnit Control_inst (
        .op      (inst_op),
        .func    (inst_func),
        .rs      (inst_rs),
        .rt      (inst_rt),
        .ern     (wdestRegw),
        .mrn     (mdestRegw),
        .mm2reg  (mm2regw),
        .mwreg   (mwregw),
        .rsrtequ (rsrtequ),
        .pcsrc   (pcsrc),
        .wpcir   (wpcir),
        .jal     (jal),
        .shift   (shift),
        .sext    (sext),
        .wreg    (out_wreg),
        .m2reg   (out_m2reg),
        .wmem    (out_wmem),
        .aluc    (out_aluc),
        .aluimm  (out_aluimm),
        .regrt   (out_regrt),
        .fwda    (fwdaw),
        .fwdb    (fwdbw)
    );

    fwdMux fwdMuxA (
        .q      (out_qa),
        .r      (ealu),
        .mr     (mrw),
        .do     (mdow),
        .select (fwdaw),
        .fwd    (MUXaw)
    );
    
    fwdMux fwdMuxB (
        .q      (out_qb),
        .r      (ealu),
        .mr     (mrw),
        .do     (mdow),
        .select (fwdbw),
        .fwd    (MUXbw)
    );
    
    Mux_RegDst MuxRegDst_inst (
        .rt      (inst_rt),
        .rd      (inst_rd),
        .regrt   (out_regrt),
        .destReg (out_destReg)
    );

    RegisterFile Register_inst (
        .rs       (inst_rs),
        .rt       (inst_rt),
        .wdestReg (wdestRegw),
        .wbData   (wbData),
        .wwreg    (wwregw),
        .clk      (clock),
        .qa       (out_qa),
        .qb       (out_qb)
    );

    SExtend Extend_inst (
        .imm   (inst_imm),
        .imm32 (out_imm32)
    );

    ID_EXE_Register IDEXE_inst (
        .clock    (clock),
        .wreg     (out_wreg),
        .m2reg    (out_m2reg),
        .wmem     (out_wmem),
        .aluc     (out_aluc),
        .aluimm   (out_aluimm),
        .destReg  (out_destReg),
        .qa       (MUXaw),
        .qb       (MUXbw),
        .imm32    (out_imm32),
        .drn      (drn),
        .jal      (jal),
        .shift    (shift),
        .dpc4     (dpc4),
        .ewreg    (ewregw),
        .em2reg   (em2regw),
        .ewmem    (ewmemw),
        .ealuc    (ealucw),
        .ealuimm  (ealuimmw),
        .edestReg (edestRegw),
        .eqa      (eqaw),
        .eqb      (eqbw),
        .eimm32   (eimm32w),
        .ern0     (ern0),
        .ejal     (ejal),
        .eshift   (eshift),
        .epc4     (epc4)
    );

    fDestReg f_destination_chooser (
        .ern0 (ern0),
        .ejal (ejal),
        .ern  (ern)
    );
    
    Mux_ALU Mux_ALU_inst (
        .eqb     (eqbw),
        .eimm32  (eimm32w),
        .ealuimm (ealuimmw),
        .b       (mux_alu_b)
    );
    
    ALU ALU_inst (
        .eqa   (mux_alu_a), 
        .b     (mux_alu_b),
        .ealuc (ealucw),
        .r     (ALU_r)
    ); 

    EXE_MEM_Register EXEMEM_inst (
        .clk      (clock),
        .ewreg    (ewregw),
        .em2reg   (em2regw),
        .ewmem    (ewmemw),
        .edestReg (ern),
        .r        (ealu),
        .eqb      (eqbw),
        .mwreg    (mwregw),
        .mm2reg   (mm2regw),
        .mwmem    (mwmemw),
        .mdestReg (mdestRegw),
        .mr       (mrw),
        .mqb      (mqbw)
    );

    DataMemory DataMemory_inst(
        .mr    (mrw),
        .mqb   (mqbw),
        .mwmem (mwmemw),
        .clk   (clock),
        .mdo   (mdow)
    );

    MEM_WB_Register MEMWB_inst (
        .clk      (clock),
        .mwreg    (mwregw),
        .mm2reg   (mm2regw),
        .mr       (mrw),
        .mdo      (mdow),
        .mdestReg (mdestRegw),
        .wwreg    (wwregw),
        .wm2reg   (wm2regw),
        .wdestReg (wdestRegw),
        .wr       (wrw),
        .wdo      (wdow)
    );

    WbMux WbMuxInst (
        .wr     (wrw),
        .wdo    (wdow),
        .wm2reg (wm2regw),
        .wbData (wbData)
    );
    assign pc = pc_current;
    assign dinstOut = out_dinst;
    assign ewreg = ewregw;
    assign em2reg = em2regw;
    assign ewmem = ewmemw;
    assign ealuc = ealucw;
    assign ealuimm = ealuimmw;
    assign edestReg = edestRegw;
    assign eqa = eqaw;
    assign eqb = eqbw;
    assign eimm32 = eimm32w;
    assign mwreg = mwregw;
    assign mm2reg = mm2regw;
    assign mwmem = mwmemw;
    assign mdestReg = mdestRegw;
    assign mr = mrw;
    assign mqb = mqbw;
    assign wwreg = wwregw;
    assign wm2reg = wm2regw;
    assign wdestReg = wdestRegw;
    assign wr = wrw;
    assign wdo = wdow;
endmodule