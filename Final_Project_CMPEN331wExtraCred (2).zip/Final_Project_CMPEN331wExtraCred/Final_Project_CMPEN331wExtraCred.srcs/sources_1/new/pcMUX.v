`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/19/2025 10:29:51 AM
// Design Name: 
// Module Name: pcMUX
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pcMUX(
    input [31:0] pc4, bpc, da, jpc,
    input [1:0] pcsrc,
    output reg [31:0] npc
    );
    always @(*) begin
        case(pcsrc)
            00: npc = pc4;
            01: npc = bpc;
            10: npc = da;
            11: npc = jpc;
        endcase
    end
endmodule
