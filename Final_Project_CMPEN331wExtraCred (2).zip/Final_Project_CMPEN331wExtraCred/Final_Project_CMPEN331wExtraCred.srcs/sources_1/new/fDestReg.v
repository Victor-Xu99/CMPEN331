`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/19/2025 10:55:40 AM
// Design Name: 
// Module Name: fDestReg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fDestReg(
        input [4:0] ern0,
        input ejal,
        output reg [4:0] ern
    );
    always @(*) begin
        ern = ejal ? 5'b11111 : ern0;
    end
endmodule
