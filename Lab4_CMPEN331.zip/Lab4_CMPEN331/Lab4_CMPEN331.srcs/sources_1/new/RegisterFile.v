`timescale 1ns / 1ps
module RegisterFile(
    input [4:0] rs,
    input [4:0] rt,
    output reg [31:0] qa,
    output reg [31:0] qb
    );
    reg [31:0] regs [0:31];
    
    initial begin: init_regs
        integer i;
        for (i=0; i < 32; i = i + 1)
            regs[i] = 0;
        end
    
    always @(*) begin
        if (rs == 5'd0)
            qa = 32'b0;
        else
            qa = regs[rs];
        if (rt == 5'd0)
            qb = 32'b0;
        else
            qb = regs[rt];
    end
endmodule
