module InstructionMemory(
        input [31:0] pc,
        output reg [31:0] instOut
    );
        reg [31:0] memory [0:63];
        initial begin
            memory[25] = 32'h8C220000; //lw $v0, 0($at)
            memory[26] = 32'h8C230004; //lw $v1, 4($at) 
            memory[27] = 32'h8C240008; // lw $4, 8($1)
            memory[28] = 32'h8C25000C; //lw $5, 12($1)
        end
            always @(*) begin
                instOut <= memory[pc[7:2]]; //Only need 6 bits since we only have 64 wods in memory
        end
endmodule
